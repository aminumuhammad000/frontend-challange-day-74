
const menu = document.querySelector('.toggle')
const side = document.querySelector('.side')

menu.addEventListener('click', (e) => {
    side.classList.toggle('active')
    if(side.classList.contains('active')){
        menu.style.color = '#fff'
        menu.textContent = 'close'
        // document.body.backgroundColor = 'red'
    }
    else{
        menu.style.color = '#000'
        menu.textContent = 'menu'
    }
})